import os
os.system('pip install -r requirements.txt')